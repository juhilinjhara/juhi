﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetReporting
{
    public class Cat : Pet
    {
        public int? numberOfLives { get; set; }
        public double CostPerVisit { get; set; }
    }
}
