﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetReporting
{
    public class Dog : Pet
    {
        public double CostPerVisit { get; set; }
    }

}
