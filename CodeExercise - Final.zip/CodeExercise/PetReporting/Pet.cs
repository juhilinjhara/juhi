﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetReporting
{
    public class Pet : Owner,IPet
    {
        public int numberofVisits { get; set; }
        public DateTime joinedPractice { get; set; }

        /// <summary>
        /// This method prints a pets reports in csv format
        /// </summary>
        /// <param name="pets">Ienumerable collection</param>
        /// <param name="filename">filename</param>
        public void printReport(IEnumerable<Pet> pets, string filename)
        {
            List<string> entries = new List<string>();
            try
            {
                entries.Add("Owners name,Date Joined Practice,Number Of Visits,Number of Lives");
                foreach (var p in pets)
                {
                    var entry = string.Join(" ", p.Firstname, p.Lastname) + p.joinedPractice + "," + p.numberofVisits;
                    if (p is Cat)
                    {
                        var cat = p as Cat;
                        entry += "," + cat.numberOfLives;
                    }

                    entries.Add(entry);
                }
                if (File.Exists(filename))
                    File.WriteAllLines(filename, entries.ToArray());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
