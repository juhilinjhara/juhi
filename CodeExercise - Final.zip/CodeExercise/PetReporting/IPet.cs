﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetReporting
{
   public interface IPet
    {
        void printReport(IEnumerable<Pet> pets, string filename);
    }
}
