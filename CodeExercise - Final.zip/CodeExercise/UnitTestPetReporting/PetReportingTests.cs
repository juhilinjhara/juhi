﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PetReporting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace UnitTestPetReporting
{
    [TestClass]
    public class MyTestClass
    {
        [TestMethod]
        public void Test1()
        {
            var pets = new List<Pet>()
            {
                new Dog() { Firstname = "Jim", Lastname = "Rogers", numberofVisits = 5, joinedPractice = DateTime.Now},
                new Dog() { Firstname = "Tony", Lastname = "Smith", numberofVisits = 10, joinedPractice = new DateTime(1985, 7, 13)},
                new Cat() { Firstname = "Steve", Lastname = "Roberts", numberofVisits = 20, joinedPractice = new DateTime(2002, 5, 6), numberOfLives = 9 }
            };

            new Pet().printReport(pets, "PetsReport.csv");
            var outPets = File.ReadAllLines("PetsReport.csv");

            Assert.AreEqual(4, outPets.Count());
        }
    }
}
